<?php
	if(explode('.', $_SERVER['HTTP_HOST'])[0] != 'config') {
		die('Error 403');
	}
	require('./inc/header.inc.php');
	if($show_site == true) {
		if (isset($_POST['repository_button'])) {
			if(isset($_POST['repository'])) {
				$headers = @get_headers($_POST['repository']);
				if($headers && strpos( $headers[0], '200')) {
				    $status = "Das Repository wird jetzt geklont. Dies kann einen Moment dauern...";
				}
				else {
				    $status = "Leider wurde das Repository nicht gefunden";
				}
			}
		}
?>
	<section id="domains">
		<?php
		$verzeichnis = "/var/www";
		if (is_dir($verzeichnis)) {
			if ($handle = opendir($verzeichnis)) {
				while (($file = readdir($handle)) !== false) {
					if(explode('.', $file)[1].'.'.explode('.', $file)[2].'.'.explode('.', $file)[3] == $data['domainname'] && is_dir($verzeichnis.'/'.$file)) {
						$subdomain_data = str_getcsv(explode(';', str_replace("\n", ";", file_get_contents($verzeichnis.'/'.$file.'/.data.csv')))[1], ',');
						if ($subdomain_data[4] == '1') {
							$request_scheme = 'https://';
						} else {
							$request_scheme = 'http://';
						}
						?>
							<section id="domain_index_<?php echo $subdomain_data[1]; ?>">
								<div class="header">
									<h1><a href="<?php echo $request_scheme.$file; ?>" rel="external" alt="<?php $subdomain_data[1]; ?>" title="Rufe die Subdomain <?php echo $file; ?> in einem neuen Tab auf" target="_blank"><?php echo $file; ?></a></h1>
								</div>
								<div class="second_header">
									<span class="header_item sitepath">Webseite unter <a href="?directory_content=<?php echo trim($file); ?>" rel="edit" alt="show directory content" title="Rufe den Verzeichnisinhalt auf um Dateien Verwalten zu können die in dem Ordner der Subdomain liegen."><?php echo $verzeichnis.'/'.$file.'/'; ?></a></span><br>
									<span class="header_item page_created">Webseite erstellt am: <strong><?php echo $subdomain_data[0]; ?> Uhr</strong></span><br>
									<span class="header_item https_redirect"><strong>Https Weiterleitung: </strong><?php if ($subdomain_data[4] == '1') { echo 'Ja - <a href="?remove_https_redirect='.trim($file).'" rel="remove" alt="remove https redirect" title="Die Weiterleitung, die in der .htaccess Datei vorhanden ist, wird entfernt. Dadurch wird die gesamte .htaccess Datei gelöscht.">Weiterleitung entfernen</a>'; } else { echo 'Nein - <a href="?add_https_redirect='.trim($file).'" rel="add" alt="add https redirect" title="Es wird eine .htaccess Datei erstellt, die eine https Weiterleitung erzwingt.">Weiterleitung hinzufügen</a>'; } ?></span><br>
									<span class="header_item ssl_email"><strong>SSL E-Mail-Adresse: </strong><a href="mailto:<?php echo $subdomain_data[3]; ?>?subject=Information%20wegen%20der%20Webseite:%20<?php echo trim($file); ?>&body=Hallo,%20%0D%0A%0D%0A" rel="mail" alt="send e-mail to subdomainowner" title="Sende dem Inhaber der Subdomain eine E-Mail, um ihn gegebenenfalls zu informieren, falls sich etwas an seiner Subdomain ändert."><?php echo $subdomain_data[3]; ?></a></span><br>
									<span class="header_item github"><strong>GitHub: </strong>
										<?php
											if (count(scandir($verzeichnis.'/'.$subdomain_data[1].'.'.$subdomain_data[2].'/httpd')) > 2) {
												if (!is_dir($verzeichnis.'/'.$subdomain_data[1].'.'.$subdomain_data[2].'/httpd/.git')) {
													echo 'Das Verzeichnis ist nicht leer.';
												} else {
													$key = hash('sha512', file_get_contents($verzeichnis.'/'.$subdomain_data[1].'.'.$subdomain_data[2].'/.data.csv'));
													$github_repo_link = explode("\n", explode('url = ', file_get_contents($verzeichnis.'/'.$subdomain_data[1].'.'.$subdomain_data[2].'/httpd/.git/config'))[1])[0];
													echo '<strong>Webhook Link</strong>
													<a href="'.str_replace('.git', '/settings/hooks/new', $github_repo_link).'" target="_blank" style="cursor: pointer;">
														<input type="text" value="https://config.'.$subdomain_data[2].'/webhook.php?'.$key.'" title="Gebe diesen Link unter '.str_replace('.git', '/settings/hooks/new', $github_repo_link).' ein. Empfolen sind die vorgegebenen Einstellungen. Kopiere den Link vorher." style="cursor: pointer;" disabled>
													</a>';
												}
											} else {
										?>
										<form method="post">
											<label for="inputRepository">
												<input type="text" name="repository" id="inputRepository" title="Trage hier ein Repository von der Plattform GitHub ein, um es zu klonen." alt="github repository" placeholder="https://github.com/nutzername/repository-name" maxlength="255" autocomplete="off" required>
											</label>
											<button type="submit" name="repository_button" title="Stelle eine Verbindung zum Repository her.">Klonen</button>
										</form>
										<?php
											}
										?>
										<p><?php echo $status; ?></p>
									</span><br>
								</div>
								<div class="third_header">
									<span class="header_item make_manually_backup"><?php if (count(scandir('/var/www/'.$file.'/httpd')) > 2) { ?><a href="?make_manually_backup=<?php echo trim($file); ?>" rel="backup" alt="make manually backup" title="Mache ein manuelles Backup aller Verzeichnisinhalte des ./htdocs/ Ordners.">Backup machen</a><?php } else { ?><abbr title="In diesem Verzeichnis sind noch keine Dateien vorhanden, sodass auch kein Backup gemacht werden kann." class="prohibited_link">Backup machen</abbr><?php } ?></span>
									<span class="header_item delete_subdomain"><?php if ($_SERVER['HTTP_HOST'] != $file) { ?><a href="?delete_subdomain=<?php echo trim($file); ?>" rel="delete" alt="delete site" title="Die Seite wird mit allen Daten endgültig gelöscht. 𝘼𝙘𝙝𝙩𝙪𝙣𝙜, 𝙙𝙞𝙚𝙨𝙚𝙧 𝙑𝙤𝙧𝙜𝙖𝙣𝙜 𝙠𝙖𝙣𝙣 𝙣𝙞𝙘𝙝𝙩 𝙧ü𝙘𝙠𝙜ä𝙣𝙜𝙞𝙜 𝙜𝙚𝙢𝙖𝙘𝙝𝙩 𝙬𝙚𝙧𝙙𝙚𝙣. Mache sicherheitshalber vorher ein Backup der Seite.">Seite löschen</a><?php } else { ?><abbr title="Diese Seite kann nicht gelöscht werden, da es sich um die Seite handelt, auf der diese Meldung gerade angezeigt wird. Wenn diese Seite gelöscht werden würde, würde gar nichts mehr funktionieren." class="prohibited_link">Seite löschen</abbr><?php } ?></span>
									<span class="header_item renew_ssl"><a href="?renew_ssl=<?php echo trim($file); ?>&email=<?php echo $subdomain_data[3]; ?>" rel="renew" alt="renew ssl certificate" title="Erneuere das SSL Zertifikat, falls du beim Aufrufen der Seite eine Meldung wie z. B.: Warnung: Mögliches Sicherheitsrisiko erkannt; bekommst. Wenn die Erneuerung nicht funktioniert, klicke nicht mehrmals oder generell unnötigerweise auf 'SSL-Zertifikat erneuern', da es passieren kann, dass die Subdomain, IP-Adresse oder deine E-Mail-Adresse für ein paar Tage gesperrt werden. Probiere es dann am besten eine Woche später erneut. Sollte auch dies nicht funktionieren, warte wieder ein paar Tage, mache ein Backup von all deinen Daten, lösche die Subdomain und benutze eine andere E-Mail-Adresse zum neu erstellen des Subdomains. Normalerweise muss es keine manuelle Erneuerung geben, da das SSL-Zertifikat automatisch erneuert wird. Wenn der Server allerdings nicht 24/7 angeschaltet ist, kann es passieren, dass das Zertifikat vor der nächsten automatischen Erneuerung abläuft. In so einem Fall kann man auf diese Funktion zurückgreifen.">SSL-Zertifikat erneuern</a></span>
								</div>
							</section>
						<?php
					}
				}
				closedir($handle);
			}
		}
		?>
		<section id="main_section">
			<div class="backup">
				<span class="backup_item backup_all"><a href="?make_manually_whole_backup=1" rel="backup" alt="make manually whole backup" title="Mache ein Backup von allen Seiten. Dabei wird jede Seite einzeln in eine Zip Datei verpackt.">Gesamtes Backup machen</a></span>
				<?php
					if (isset($data['mysql_username'])) {
				?>
				<span class="backup_item backup_all_dbs"><a href="?make_manually_whole_db_backup=1" rel="backup" alt="make manually whole db backup" title="Mache ein Backup von allen Datenbanken. Dabei wird jede einzelne Datenbank als SQL-Datei abgespeichert.">Datenbanken Backup machen</a></span>
			<?php } ?>
			</div>
			<div>
				<span class="list_element"><strong class="title">Interne IP-Adresse:</strong> <?php echo $_SERVER['SERVER_ADDR']; ?></span>
				<span class="list_element phpmyadmin_button"><a href="<?php echo $_SERVER['REQUEST_SCHEME'].'://'.'phpmyadmin.'.$data['domainname'] ?>" rel="external" alt="phpmyadmin" title="MySQL Datenbanken verwalten" target="_blank">phpMyAdmin</a></span>
				<span class="list_element"><strong class="title">Externe IP-Adresse:</strong> <?php echo $_SERVER['REMOTE_ADDR']; ?></span>
			</div>
			<div class="databases">
				<details class="database_details">
					<summary>Datenbank Zugangsdaten</summary>
					<form method="post">
						<label for="inputUsername">
							<input type="text" name="username" id="inputUsername" value="<?php echo $data['mysql_username']; ?>" title="Gebe den root Benutzernamen des MySQL Benutzers ein. Dieser wird dafür verwendet, um andere Benutzer zu erstellen und hier die Datenbanken zu verwalten." alt="mysql username" placeholder="MySQL-Benutzername (root)" maxlength="32" autocomplete="off" required>
						</label>
						<label for="inputPassword">
							<input type="password" name="password" id="inputPassword" title="Gebe das zugehörige MySQL-Passwort ein." alt="mysql password" placeholder="MySQL-Passwort" maxlength="32" autocomplete="off" required>
						</label>
						<button type="submit" name="mysql_login" title="Logge dich mit den MySQL Zugangsdaten ein.">Anmelden</button>
					</form>
					<?php
						if (isset($data['mysql_username'])) {
					?>
					<form method="post" class="unset db_logout">
						<button type="submit" name="mysql_logout" title="Lösche die MySQL Zugangsdaten.">Abmelden</button>
					</form>
				<?php } ?>
				</details>
				<details class="config_password_details">
					<summary>Config Passwort</summary>
					<form method="post">
						<label for="inputPassword">
							<input type="password" id="inputPassword" name="password" title="Passwort zum einloggen der Config Seite" alt="password" placeholder="Passwort der Config Seite" autocomplete="off" maxlength="32" required>
						</label>
						<button type="submit" name="change_config_password" title="Speichere das neue Passwort ab.">Speichern</button>
					</form>
				</details>
			</div>
		</section>
		<form method="post" id="newsubdomain">
			<label for="inputSubname">
				<input type="text" id="inputSubname" name="subname" placeholder="Subdomain Name (nur der Subname)" pattern="[abcdefghijklmnopqrstuvwxyz0123456789\-]+" title="Bitte verwende nur Kleinbuchstaben und Zahlen und maximal ein Minuszeichen, welches sich nicht an der ersten, dritten, vierten oder letzten Stelle befindet." maxlength="40" required>
			</label>
			<label for="inputMail">
				<input type="email" id="inputMail" name="mail" placeholder="E-Mail-Adresse" value="<?php echo trim($_COOKIE['mail']); ?>" pattern="^[\w\.\+\-]+\@[\w\-]+\.[a-z]{2,3}$" title="Bitte gebe eine gültige E-Mail-Adresse an." minlength="6" maxlength="120" required>
			</label>
			<label for="inputRedirect">
				<input type="checkbox" id="inputRedirect" name="redirect" checked> Automatische <i>https://</i> weiterleitung
			</label>
			<button type="submit" name="newsubdomain">Neue Subdomain erstellen</button>
		</form>
	</section>
	<section id="main">
		<?php echo $msg_field; ?>
		<?php
			include('./inc/files.inc.php');
		?>
	</section>
<?php
	}
	require('./inc/footer.inc.php');
?>
