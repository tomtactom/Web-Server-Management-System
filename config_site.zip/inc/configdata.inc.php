<?php
$password = "start";
