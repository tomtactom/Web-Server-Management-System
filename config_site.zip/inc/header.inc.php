<?php
	require('./inc/configdata.inc.php');
  include('./inc/dbaccessdata.inc.php');
  $data['full_domain'] = $_SERVER['REQUEST_SCHEME'].'://'.$_SERVER['HTTP_HOST'];
  $data['domainname'] = explode('.', $_SERVER['HTTP_HOST'])[1].'.'.explode('.', $_SERVER['HTTP_HOST'])[2].'.'.explode('.', $_SERVER['HTTP_HOST'])[3];

  // Eigene URL mit und ohne GET-Parameter
  if($_SERVER['SERVER_PORT']) {
	$data['own_url_with_get'] = 'https://'.$_SERVER['HTTP_HOST'].$_SERVER['REQUEST_URI'];
	$data['own_url'] = 'https://'.$_SERVER['HTTP_HOST'].explode('?', $_SERVER['REQUEST_URI'])[0];
  } else {
	$data['own_url_with_get'] = 'http://'.$_SERVER['HTTP_HOST'].$_SERVER['REQUEST_URI'];
	$data['own_url'] = 'http://'.$_SERVER['HTTP_HOST'].explode('?', $_SERVER['REQUEST_URI'])[0];
  }

  $authcode_hash = hash('sha512', '5si*YTGdtUdV1"gaF1>yOG^0C"rSRpca0WZ6:)nw1Xe,|$');
  // Wenn die App den richtigen `authcode` per GET übermittelt oder der COOKIE `authcode` gesetzt ist und mit dem oben generierten $authcode_hash übereinstimmt, wird das Configuration Panel angezeigt
  if($_COOKIE["authcode"] === $authcode_hash) {
    $show_site = true;
    // Ansonnsten wird das Anmeldeformular angezeigt
  } else {
	// Überprüft ob das Formular abgesendet wurde
    if(isset($_POST['authenticate'])) {
      // Überprüft ob das Passwortfeld Ihnalt hat und ob das Fake Captcha leer ist
      if(!empty($_POST['password'])) {
        // Überprüft das eingegebene Passwort mit dem Hash. Wenn dies übereinstimmt wird der Vertretungsplan angezeigt und der COOKIE `authcode` mit dem $authcode_hash für 12 Stunden gesetzt
        if (hash('sha512', 'd[0<~]PH'.$_POST['password'].'94j|i4BY') === hash('sha512', 'd[0<~]PH'.$password.'94j|i4BY')) {
          $show_site = true;
          setcookie("authcode", $authcode_hash, time() + (3600 * 12));
          // Wenn es nicht übereinstimmt wird die jeweilige Benachrichtigung angezeigt
        } else {
          $msg = 'Das<span style="color: transparent;">'.rand(0, 9).'</span>Passwort<span style="color: transparent;">'.rand(0, 9).'</span>war<span style="color: transparent;">'.rand(0, 9).'</span>leider<span style="color: transparent;">'.rand(0, 9).'</span>falsch'; // rand(0, 9), ist als Sicherheitsvorkehrung vor Brute Force Angriffen wie von hydra.
        }
        // Wenn das Passwort Feld leer ist oder das Captcha Feld ausgefüllt wurde, wird die jeweilige Benachrichtigung angezeigt
      } else {
        $msg = 'Bitte gebe ein Passwort ein';
      }
    }
  }

  // Code der nur ausgeführt werden darf, wenn der Nutzer eingeloggt ist
  if($show_site == true) {
    // Neue Subdomain anlegen
  	if(isset($_POST['newsubdomain'])) {
  		if(!empty($_POST['subname']) && !empty($_POST['mail'])) {
  			if(!preg_match('/^[abcdefghijklmnopqrstuvwxyz0123456789\-]+$/', $_POST['subname'])) {
  				$error = true;
  				$msg = "Bitte halte dich beim Subdomain Namen an das richtige Format";
  			}
  			if (!filter_var($_POST['mail'], FILTER_VALIDATE_EMAIL)) {
  				$error = true;
  				$msg = "Bitte gebe eine gültige E-Mail-Adresse ein";
  			} else {
  				setcookie("mail", trim($_POST['mail']), time() + (3600*24*100));
  			}
  			if($_POST['subname'][0] == '-' || $_POST['subname'][2] == '-' || $_POST['subname'][3] == '-' || $_POST['subname'][-1] == '-') {
  				$error = true;
  				$msg = 'Das erste, dritte, vierte und letzte Zeichen, darf kein Minuszeichen sein';
  			}
  			if(strlen($_POST['subname']) > 40 || strlen($_POST['mail']) > 120) {
  				$error = true;
  				$msg = 'Bitte halte dich an die maximale Zeichenangabe';
  			}
  			$verzeichnis = "/var/www";
  			if (is_dir($verzeichnis)) {
  				if ($handle = opendir($verzeichnis)) {
  					while (($file = readdir($handle)) !== false) {
  						if(explode('.', $file)[1].'.'.explode('.', $file)[2].'.'.explode('.', $file)[3] == $data['domainname'] && is_dir($verzeichnis.'/'.$file)) {
  							if(explode('.', $file)[0] == $_POST['subname']) {
  								$error = true;
  								$msg = 'Dieser Subdomainname existiert bereits.';
  								break;
  							}
  						}
  					}
  				}
  			} else {
  				$msg = 'Etwas stimmt mit dem Webseitenordner nicht.';
  				$error = true;
  			}
  			if(!isset($error)) {
  				if($_POST['redirect'] == true) {
  					$redirect = '1';
  				} else {
  					$redirect = '0';
  				}
  				$subname = trim($_POST['subname']);
  				$mail = trim($_POST['mail']);
  				$result = shell_exec("sudo python3 /etc/apache2/new_subdomain.py ".$subname." ".$mail." ".$redirect);
  				$msg = 'Subdomain wurde erfolgreich angelegt.';
  			}
  		} else {
  			$msg = "Bitte fülle alle Felder aus.";
  		}
  	}

    // Subdomain löschen
  	if(isset($_GET['delete_subdomain'])) {
      if ($_SERVER['HTTP_HOST'] != $file) {
    		$result = shell_exec("sudo python3 /etc/apache2/remove_subdomain.py ".trim(explode('.', $_GET['delete_subdomain'])[0]));
    		if ($result == true) {
    			$msg = 'Die Subdomain wurde endgültig gelöscht.';
    		} else {
    			$msg = 'Es ist ein Fehler aufgetreten. Probiere es bitte erneut. Eventuell musst du die Domain manuell entfernen.';
    		}
      } else {
        $msg = 'Diese Seite kann nicht gelöscht werden, da es sich um die Seite handelt, auf der diese Meldung gerade angezeigt wird. Wenn diese Seite gelöscht werden würde, würde gar nichts mehr funktionieren.';
      }
      setcookie('msg', $msg, time() + 60);
  		header('Location: '.$data['own_url']);
  	}

    // https Weiterleitung entfernen
    if(isset($_GET['remove_https_redirect'])) {
      $result = shell_exec("sudo python3 /etc/apache2/remove_https_redirect.py ".trim(explode('.', $_GET['remove_https_redirect'])[0]));
      if ($result == true) {
  			$msg = 'Die https Weiterleitung wurde erfolgreich entfernt';
  		} else {
  			$msg = 'Es ist ein Fehler aufgetreten. Probiere es bitte erneut. Eventuell musst du die Weiterleitung manuell entfernen. Lösche dazu die .htaccess Datei und ändere in der .data.csv Datei beim Eintrag "redirection", die 1 zu einer 0.';
  		}
      setcookie('msg', $msg, time() + 60);
  		header('Location: '.$data['own_url']);
    }

    // https Weiterleitung hinzufügen
    if(isset($_GET['add_https_redirect'])) {
      $result = shell_exec("sudo python3 /etc/apache2/add_https_redirect.py ".trim(explode('.', $_GET['add_https_redirect'])[0]));
      if ($result == true) {
  			$msg = 'Die https Weiterleitung wurde erfolgreich hinzugefügt';
  		} else {
  			$msg = 'Es ist ein Fehler aufgetreten. Probiere es bitte erneut. Eventuell musst du die Weiterleitung manuell hinzufügen. Erstelle dazu eine .htaccess Datei (Im gleichen Verzeichnis, in der sich auch die .data.csv befindet) und ändere in der .data.csv Datei beim Eintrag "redirection", die 0 zu einer 1.';
  		}
      setcookie('msg', $msg, time() + 60);
  		header('Location: '.$data['own_url']);
    }

    // Manuelles Backup machen
    if(isset($_GET['make_manually_backup'])) {
      if (count(scandir('/var/www/'.$_GET['make_manually_backup'].'/httpd')) > 2) {
        $result = shell_exec("sudo python3 /etc/apache2/make_manually_backup.py ".trim(explode('.', $_GET['make_manually_backup'])[0]));
        if ($result == true) {
    			$msg = 'Es wurde erfolgreich ein manuelles Backup gemacht, welches sich <a href="'.$data['full_domain'].'/backups/'.trim($result).'" rel="download" alt="'.trim($result).'" title="Lade dir das eben gemachte Backup herunter."><strong>hier</strong></a> herunterladen lässt.';
    		} else {
    			$msg = 'Es ist ein Fehler aufgetreten. Probiere es bitte erneut. Eventuell musst du das Backup manuell machen.';
    		}
      } else {
        $msg = 'In diesem Verzeichnis sind noch keine Dateien vorhanden, sodass auch kein Backup gemacht werden kann.';
      }
        setcookie('msg', $msg, time() + 60);
    		header('Location: '.$data['own_url']);
    }

    // Manuelles gesamtes Backup machen
    if(isset($_GET['make_manually_whole_backup'])) {
      $counter = 0;
      $counter_fail = 0;
      $verzeichnis = "/var/www";
  		if (is_dir($verzeichnis)) {
  			if ($handle = opendir($verzeichnis)) {
  				while (($file = readdir($handle)) !== false) {
  					if(explode('.', $file)[1].'.'.explode('.', $file)[2].'.'.explode('.', $file)[3] == $data['domainname'] && is_dir($verzeichnis.'/'.$file)) {
              if (count(scandir('/var/www/'.$file.'/httpd')) > 2) {
                $result = shell_exec("sudo python3 /etc/apache2/make_manually_backup.py ".trim(explode('.', $file)[0]));
                if ($result == false) {
                  $counter_fail++;
                }
                $counter++;
              }
            }
          }
        }
      }
      if ($counter_fail == 0) {
        if ($counter > 0) {
          if($counter == 1) {
            $msg = 'Es wurde von einer Seite ein Backup gemacht';
          } else {
            $msg = 'Es wurde von allen <strong>'.$counter.'</strong> Seiten ein Backup gemacht.';
          }
        } else {
          $msg = 'Es wurde keine Seite gefunden von der ein Backup hätte gemacht werden können.';
        }
      } else {
        if ($counter > 0) {
          if($counter == 1) {
            if($counter_fail == 1) {
              $msg = 'Es wurde von einer Seite ein Backup gemacht. Bei einer Seite trat ein Fehler auf. Bitte überprüfe manuell um welche Seite es sich dabei handelt.';
            } else {
              $msg = 'Es wurde von einer Seite ein Backup gemacht. Bei '.$counter_fail.' Seiten traten Fehler auf. Bitte überprüfe manuell um welche Seiten es sich dabei handelt.';
            }
          } else {
            $msg = 'Es wurde keine Seite gefunden von der ein Backup hätte gemacht werden können.';
          }
        } else {
          $msg = 'Es wurde keine Seite gefunden von der ein Backup hätte gemacht werden können.';
        }
      }
      setcookie('msg', $msg, time() + 60);
      header('Location: '.$data['own_url']);
    }

    // SSL-Zertifikat erneuern
    if (isset($_GET['renew_ssl'])) {
      if (isset($_GET['email'])) {
        $result = shell_exec('sudo letsencrypt --apache -d '.$_GET['renew_ssl'].' --agree-tos -m '.$_GET['email'].' --no-eff-email --no-redirect --renew-by-default');
        if ($result == true) {
          $msg = '<abbr title="'.trim($result).'">Es scheint so, als ob alles funktioniert hat.</abbr>';
        } else {
          $msg = 'Es scheint so, als ob es nicht funktioniert hat.';
        }
      } else {
        $msg = 'Es wurde keine E-Mail überliefert, die bei der Erneuerung angegeben werden muss.';
      }
      setcookie('msg', $msg, time() + 60);
      header('Location: '.$data['own_url']);
    }

    // Mit Root in Datenbank einloggen und Zugangsdaten abspeichern bzw. ausloggen; die Datei mit den Zugangsdaten löschen
    if(isset($_POST['mysql_login'])) {
      if(isset($_POST['username']) && strlen($_POST['username']) <= 32) {
          if(isset($_POST['password']) && strlen($_POST['password']) <= 32) {
            $db_link = mysqli_connect('localhost', $_POST['username'], $_POST['password'], 'phpmyadmin');
            if ($db_link == true) {
              $data = '<?php
  $data["mysql_username"] = "'.$_POST['username'].'";
  $data["mysql_password"] = "'.$_POST['password'].'";
';
              file_put_contents('./inc/dbaccessdata.inc.php', $data);
              $msg = 'Es wurde sich erfolgreich mit den Zugangsdaten verbunden.';
            } else {
              $msg = 'Es konnte keine Verbundung hergestellt werden. Vermutlich ist der Benutzername oder das Passwort falsch oder der Benutzer hat nicht die nötigen Berechtigungen. '.mysqli_error();
            }
          } else {
            $msg = 'Bitte gebe ein gültiges Passwort ein.';
          }
      } else {
        $msg = 'Bitte gebe einen gültigen Benutzernamen ein.';
      }
      setcookie('msg', $msg, time() + 60);
      header('Location: '.explode('<', $data['own_url_with_get'])[0]);
    } elseif (isset($_POST['mysql_logout'])) {
      $result = unlink('./inc/dbaccessdata.inc.php');
      if($result == true) {
        $msg = 'Du wurdest erfolgreich abgemeldet.';
      } else {
        $msg = 'Du konntest leider nicht abgemeldet werden.';
      }
      setcookie('msg', $msg, time() + 60);
      header('Location: '.explode('<', $data['own_url'])[0]);
    }

    // Config Passwort ändern
    if (isset($_POST['change_config_password'])) {
      if(isset($_POST['password']) && strlen($_POST['password']) <= 32) {
      $data = '<?php
$password = "'.trim($_POST['password']).'";
';
        file_put_contents('./inc/configdata.inc.php', $data);
        $msg = 'Das Passwort wurde erfolgreich geändert.';
      } else {
        $msg = 'Bitte gebe ein gültiges Passwort ein.';
      }
      setcookie('msg', $msg, time() + 60);
      header('Location: '.explode('<', $data['own_url'])[0]);
    }
  }

  // Nachricht die in Cookie an die nächste Seite übermittelt wurde in $msg abspeichern
  if(!empty($_COOKIE['msg'])) {
    $msg = trim($_COOKIE['msg']);
    setcookie('msg', '', time() - 3600);
  }
	if(isset($msg)) {
		$msg_field = '<div class="message"><span onclick="this.parentElement.style.display=\'none\';" style="float: right; cursor: pointer;">×</span> '.trim($msg).'&nbsp;&nbsp;&nbsp;</div>';
	}
?>
<html lang="de">
	<head>
		<meta charset="utf-8">
		<title>Webserver Configuration Panel</title>
		<meta name="language" content="de">
		<meta name="date" content="2019-08-16">
		<meta name="keywords" content="webserver, configuration, panel">
		<meta name="description" content="Create subdomains with just one click and manage your server.">
		<meta name="robots" content="noindex, nofollow">
		<meta name="author" content="Tom Aschmann">
		<meta name="copyright" content="©<?php echo date('Y'); ?> Tom Aschmann">
		<meta name="publisher" content="Tom Aschmann">
		<meta name="msapplication-TileColor" content="#38ada9">
		<meta name="theme-color" content="#38ada9">
		<meta name="msapplication-TileImage" content="./assets/icon/ms-icon-144x144.png">
		<meta http-equiv="language" content="deutsch, de">
		<link rel="apple-touch-icon" sizes="57x57" href="./assets/icon/apple-icon-57x57.png">
		<link rel="apple-touch-icon" sizes="60x60" href="./assets/icon/apple-icon-60x60.png">
		<link rel="apple-touch-icon" sizes="72x72" href="./assets/icon/apple-icon-72x72.png">
		<link rel="apple-touch-icon" sizes="76x76" href="./assets/icon/apple-icon-76x76.png">
		<link rel="apple-touch-icon" sizes="114x114" href="./assets/icon/apple-icon-114x114.png">
		<link rel="apple-touch-icon" sizes="120x120" href="./assets/icon/apple-icon-120x120.png">
		<link rel="apple-touch-icon" sizes="144x144" href="./assets/icon/apple-icon-144x144.png">
		<link rel="apple-touch-icon" sizes="152x152" href="./assets/icon/apple-icon-152x152.png">
		<link rel="apple-touch-icon" sizes="180x180" href="./assets/icon/apple-icon-180x180.png">
		<link rel="icon" type="image/png" sizes="192x192"	href="./assets/icon/android-icon-192x192.png">
		<link rel="icon" type="image/png" sizes="32x32" href="./assets/icon/favicon-32x32.png">
		<link rel="icon" type="image/png" sizes="96x96" href="./assets/icon/favicon-96x96.png">
		<link rel="icon" type="image/png" sizes="16x16" href="./assets/icon/favicon-16x16.png">
		<link rel="manifest" href="./assets/manifest.json">
		<link rel="stylesheet" type="text/css" href="./assets/style.css">
		<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
	</head>
	<body>
		<?php
			if($show_site == true) {
		?>
		<header>

		</header>
		<?php
			}
		?>
		<article>
		<?php
			if($show_site == false) {
		?>
			<section>
				<form method="post">
					<h3>Webserver Configuration Panel</h3>
					<h4>Logge dich ein, um den Webserver zu verwalten</h4>
					<?php if(!empty($msg)) { ?>
						<h4><?php echo $msg; ?></h4>
					<?php } ?>
					<label>Passwort:
						<input type="password" name="password" placeholder="Passwort" title="Gebe hier das Passwort ein um auf das Webserver Configuration Panel zuzugreifen" maxlength="64" autofocus required>
					</label>
					<button type="submit" name="authenticate" title="Du bleibt für 12 Stunden angemeldet">Anmelden</button>
				</form>
			</section>
		<?php
			}
		?>
